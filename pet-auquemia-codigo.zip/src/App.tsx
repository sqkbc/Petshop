import { useState } from 'react';
import { MotionConfig } from 'motion/react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ServicesSection } from './components/ServicesSection';
import { GallerySection } from './components/GallerySection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';

export default function App() {
  const [selectedServiceSubject, setSelectedServiceSubject] = useState('');

  const handleSelectService = (serviceTitle: string) => {
    setSelectedServiceSubject(serviceTitle);
    const target = document.getElementById('contato');
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen flex flex-col bg-canvas text-ink font-sans selection:bg-ink selection:text-canvas">
        <Navbar />

        <main className="flex-1">
          <HeroSection />
          <ServicesSection onSelectService={handleSelectService} />
          <GallerySection />
          <ContactSection preselectedSubject={selectedServiceSubject} />
        </main>

        <Footer />
      </div>
    </MotionConfig>
  );
}
