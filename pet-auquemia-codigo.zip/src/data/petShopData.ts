export interface PetService {
  id: string;
  index: string;
  title: string;
  summary: string;
  category: string;
  accentWash: 'gold' | 'rose' | 'sage' | 'lavender' | 'sky';
  image?: string;
  imageAlt?: string;
}

export interface GalleryPhoto {
  id: string;
  src: string;
  alt: string;
  caption: string;
}

export const WHATSAPP_NUMBER = '558499995587';
export const PHONE_DISPLAY = '(84) 9999-5587';
export const ADDRESS_FULL =
  'Rua Projetada 18, S/N, Na rua entre o Colégio e o Ponto de Mototáxi, à esquerda - Av. José Cavalcante - Bela Vista, Uruçuí - PI, 64860-000';

export function buildWhatsAppUrl(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export const HERO_IMAGE = {
  src: '/assets/aistudio/IMG_6145_41015202.jpeg',
  alt: 'Ilustração Pet Shop da Pet Auquemia com gato e cachorro felizes',
};

export const SERVICES: PetService[] = [
  {
    id: 'banho-terapeutico',
    index: '01',
    title: 'Banho Terapêutico',
    summary: 'Água morna, xampu suave e secagem calma sem estresse.',
    category: 'Higiene',
    accentWash: 'gold',
    image: '/src/assets/images/service_bath_spa_1794954388805.jpg',
    imageAlt: 'Cão maltês relaxado durante banho terapêutico com espuma suave',
  },
  {
    id: 'tosa-tesoura',
    index: '02',
    title: 'Tosa na Tesoura & Higiênica',
    summary: 'Acabamento artesanal respeitando o conforto e a raça.',
    category: 'Estética',
    accentWash: 'rose',
    image: '/src/assets/images/service_grooming_scissors_1794954388824.jpg',
    imageAlt: 'Tosadora realizando acabamento cuidadoso na tesoura em poodle caramelo',
  },
  {
    id: 'hidratacao-pelagem',
    index: '03',
    title: 'Hidratação de Pelagem',
    summary: 'Nutrição profunda para fios macios, alinhados e brilhantes.',
    category: 'Tratamento',
    accentWash: 'lavender',
  },
  {
    id: 'unhas-ouvidos',
    index: '04',
    title: 'Corte de Unhas & Ouvidos',
    summary: 'Cuidado delicado de rotina para saúde e bem-estar diário.',
    category: 'Rotina',
    accentWash: 'sage',
  },
  {
    id: 'spa-patinhas',
    index: '05',
    title: 'Spa de Patinhas',
    summary: 'Limpeza entre coxins e bálsamo hidratante natural.',
    category: 'Bem-estar',
    accentWash: 'sky',
  },
  {
    id: 'taxi-dog',
    index: '06',
    title: 'Táxi Dog Uruçuí',
    summary: 'Busca e entrega segura direto na sua casa em Uruçuí.',
    category: 'Conveniência',
    accentWash: 'gold',
  },
];

export const GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'caramelo-feliz',
    src: '/src/assets/images/gallery_caramelo_dog_1794954390723.jpg',
    alt: 'Cão caramelo com pelagem brilhante e coleira dourada dentro da Pet Auquemia',
    caption: 'Pelagem brilhante e olhar tranquilo depois do banho.',
  },
  {
    id: 'cuidado-felinos',
    src: '/src/assets/images/gallery_cat_care_1794954391778.jpg',
    alt: 'Gato laranja sendo escovado com delicadeza em ambiente calmo',
    caption: 'Atendimento sereno e adaptado também para felinos.',
  },
  {
    id: 'loja-acolhedora',
    src: '/src/assets/images/gallery_boutique_interior_1794954392597.jpg',
    alt: 'Interior acolhedor da Pet Auquemia com prateleiras em madeira e iluminação dourada',
    caption: 'Nosso espaço preparado para receber você e seu amigo.',
  },
];
