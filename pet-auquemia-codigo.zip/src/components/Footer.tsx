import { Dog, MessageCircle } from 'lucide-react';
import {
  ADDRESS_FULL,
  PHONE_DISPLAY,
  buildWhatsAppUrl,
} from '../data/petShopData';

export function Footer() {
  const whatsappHref = buildWhatsAppUrl(
    'Olá, Pet Auquemia! Gostaria de mais informações.'
  );

  return (
    <footer className="bg-canvas text-ink border-t border-hairline">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10 py-16 lg:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-12">
          {/* Column 1: Brand */}
          <div className="space-y-4">
            <a
              href="#inicio"
              className="inline-flex items-center gap-2.5 text-ink"
            >
              <span className="inline-flex items-center justify-center w-9 h-9 rounded-xl bg-ink text-canvas">
                <Dog className="w-5 h-5" strokeWidth={2.2} aria-hidden="true" />
              </span>
              <span className="font-display font-semibold text-xl text-ink">
                Pet Auquemia
              </span>
            </a>
            <p className="text-sm font-medium text-ink-muted leading-relaxed max-w-xs">
              Cuidado artesanal, banho, tosa e atenção especial para o bem-estar do seu pet em Uruçuí.
            </p>
          </div>

          {/* Column 2: Navigation */}
          <div className="space-y-3">
            <p className="font-display font-semibold text-base text-ink">
              Navegação
            </p>
            <ul className="space-y-2.5 text-sm font-semibold text-ink-muted">
              <li>
                <a href="#inicio" className="hover:text-ink transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-ink transition-colors">
                  Serviços
                </a>
              </li>
              <li>
                <a href="#galeria" className="hover:text-ink transition-colors">
                  Galeria
                </a>
              </li>
              <li>
                <a href="#contato" className="hover:text-ink transition-colors">
                  Contato
                </a>
              </li>
            </ul>
          </div>

          {/* Column 3: Address */}
          <div className="space-y-3">
            <p className="font-display font-semibold text-base text-ink">
              Onde estamos
            </p>
            <p className="text-sm font-medium text-ink-muted leading-relaxed">
              {ADDRESS_FULL}
            </p>
          </div>

          {/* Column 4: Direct Contact */}
          <div className="space-y-4">
            <p className="font-display font-semibold text-base text-ink">
              Atendimento
            </p>
            <p className="text-sm font-bold text-ink tabular-nums">{PHONE_DISPLAY}</p>
            <a
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-ink text-canvas text-sm font-bold whitespace-nowrap shrink-0 transition-colors hover:bg-ink-soft"
            >
              <MessageCircle className="w-4 h-4" aria-hidden="true" />
              <span>Falar no WhatsApp</span>
            </a>
          </div>
        </div>

        <div className="mt-14 pt-8 border-t border-hairline flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-semibold text-ink-muted">
          <p>© {new Date().getFullYear()} Pet Auquemia · Uruçuí, Piauí</p>
          <p>Feito com carinho para cães e gatos.</p>
        </div>
      </div>
    </footer>
  );
}
