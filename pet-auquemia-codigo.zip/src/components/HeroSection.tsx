import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import { HERO_IMAGE } from '../data/petShopData';
import { PetImage } from './PetImage';

export function HeroSection() {
  return (
    <section
      id="inicio"
      className="relative pt-24 pb-16 lg:pt-28 lg:pb-24 min-h-[calc(100svh-3.5rem)] flex items-center bg-canvas text-ink"
    >
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Editorial Copy Column */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 space-y-6 lg:space-y-8"
          >
            <p className="text-sm font-bold tracking-wide text-ink">
              Pet Shop em Uruçuí · Piauí
            </p>

            <h1 className="font-display font-semibold text-ink text-[clamp(2.55rem,5vw,4.65rem)] leading-[1.04] tracking-tight">
              Carinho que transforma o dia do seu pet.
            </h1>

            <p className="text-base sm:text-lg font-medium text-ink-muted max-w-md leading-relaxed">
              Banho, tosa artesanal e cuidado completo para o bem-estar de cães e gatos, sem pressa.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <a
                href="#contato"
                className="group inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full bg-ink text-canvas font-bold text-base whitespace-nowrap shrink-0 transition-all duration-200 hover:bg-ink-soft hover:-translate-y-0.5 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
              >
                <span>Entrar em contato</span>
                <ArrowRight
                  className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1"
                  aria-hidden="true"
                />
              </a>

              <a
                href="#servicos"
                className="inline-flex items-center px-4 py-3 text-[15px] font-bold text-ink whitespace-nowrap shrink-0 transition-opacity hover:opacity-75 underline decoration-ink decoration-2 underline-offset-4"
              >
                Conhecer serviços
              </a>
            </div>
          </motion.div>

          {/* Hero Photography Column */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.65, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6"
          >
            <div className="relative max-w-[520px] mx-auto lg:ml-auto lg:mr-0">
              <div
                aria-hidden="true"
                className="hidden sm:block absolute -inset-3 rounded-[2.75rem] border-2 border-ink pointer-events-none translate-x-2 translate-y-2"
              />
              <div className="relative rounded-[2rem] lg:rounded-[2.5rem] overflow-hidden bg-illustration aspect-square shadow-2xl shadow-ink/15 border border-ink/20">
                <PetImage
                  src={HERO_IMAGE.src}
                  alt={HERO_IMAGE.alt}
                  loading="eager"
                  fetchPriority="high"
                  className="w-full h-full object-contain"
                />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
