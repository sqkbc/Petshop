import { useEffect, useState, type FormEvent } from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, MapPin, MessageCircle, Phone } from 'lucide-react';
import {
  ADDRESS_FULL,
  PHONE_DISPLAY,
  SERVICES,
  buildWhatsAppUrl,
} from '../data/petShopData';

interface ContactSectionProps {
  preselectedSubject: string;
}

export function ContactSection({ preselectedSubject }: ContactSectionProps) {
  const [ownerName, setOwnerName] = useState('');
  const [petName, setPetName] = useState('');
  const [subject, setSubject] = useState(
    preselectedSubject || SERVICES[0].title
  );
  const [message, setMessage] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  useEffect(() => {
    if (preselectedSubject) {
      setSubject(preselectedSubject);
      setSubmittedUrl(null);
    }
  }, [preselectedSubject]);

  const directWhatsAppUrl = buildWhatsAppUrl(
    'Olá! Gostaria de falar com a Pet Auquemia sobre agendamento e cuidados para meu pet.'
  );

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmedOwner = ownerName.trim();
    const trimmedPet = petName.trim();

    if (trimmedOwner.length < 2) {
      setError('Por favor, informe seu nome para continuarmos.');
      return;
    }

    setError(null);

    const lines = [
      `Olá, Pet Auquemia! Meu nome é ${trimmedOwner}.`,
      trimmedPet ? `Pet: ${trimmedPet}` : null,
      `Interesse: ${subject}`,
      message.trim() ? `Mensagem: ${message.trim()}` : null,
    ].filter(Boolean);

    const url = buildWhatsAppUrl(lines.join('\n'));
    setSubmittedUrl(url);
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <section
      id="contato"
      className="py-24 lg:py-32 bg-surface text-ink border-t border-hairline"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Location & Direct WhatsApp CTA */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 space-y-8"
          >
            <div className="space-y-4">
              <p className="text-sm font-bold text-ink">
                Contato e agendamento
              </p>
              <h2 className="font-display font-semibold text-ink text-[clamp(2.15rem,4vw,3.4rem)] leading-[1.06] tracking-tight">
                Vamos cuidar do seu pet?
              </h2>
              <p className="text-base font-medium text-ink-muted leading-relaxed">
                Envie sua mensagem ou agende diretamente pelo WhatsApp da Pet Auquemia.
              </p>
            </div>

            <div className="space-y-5 pt-2">
              <div className="flex items-start gap-3.5">
                <span className="inline-flex items-center justify-center w-10 h-10 rounded-2xl bg-ink text-canvas shrink-0">
                  <MapPin className="w-5 h-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-ink">Endereço em Uruçuí</p>
                  <p className="text-sm font-medium text-ink-muted leading-relaxed">
                    {ADDRESS_FULL}
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5">
                <span className="inline-flex items-center justify-center w-10 h-10 rounded-2xl bg-ink text-canvas shrink-0">
                  <Phone className="w-5 h-5" aria-hidden="true" />
                </span>
                <div className="space-y-1">
                  <p className="text-xs font-bold text-ink">Telefone & WhatsApp</p>
                  <a
                    href={directWhatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-base font-bold text-ink tabular-nums underline decoration-ink/40 underline-offset-4 hover:decoration-ink transition-colors"
                  >
                    {PHONE_DISPLAY}
                  </a>
                </div>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={directWhatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-3 px-7 py-4 rounded-full bg-ink text-canvas font-bold text-base whitespace-nowrap shrink-0 transition-all duration-200 hover:-translate-y-0.5 hover:bg-ink-soft focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
              >
                <MessageCircle className="w-5 h-5" aria-hidden="true" />
                <span>Chamar no WhatsApp</span>
              </a>
            </div>
          </motion.div>

          {/* Right Column: Yellow Elevated Card with Black Text */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-80px' }}
            transition={{ duration: 0.6, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7"
          >
            <div className="rounded-[2rem] bg-elevated text-ink border border-ink/20 p-7 sm:p-10 shadow-xl shadow-ink/10">
              <h3 className="font-display font-semibold text-2xl text-ink mb-6">
                Agende ou tire sua dúvida
              </h3>

              <form onSubmit={handleSubmit} noValidate className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label
                      htmlFor="contact-owner"
                      className="block text-sm font-bold text-ink"
                    >
                      Seu nome
                    </label>
                    <input
                      id="contact-owner"
                      type="text"
                      required
                      value={ownerName}
                      onChange={(e) => {
                        setOwnerName(e.target.value);
                        if (error) setError(null);
                      }}
                      placeholder="Ex.: Mariana Silva"
                      className="w-full px-4 py-3 rounded-xl bg-canvas/80 border border-ink/25 text-ink placeholder:text-ink-muted/60 text-sm font-medium focus:outline-none focus:border-ink transition-colors"
                    />
                  </div>

                  <div className="space-y-2">
                    <label
                      htmlFor="contact-pet"
                      className="block text-sm font-bold text-ink"
                    >
                      Nome do pet
                    </label>
                    <input
                      id="contact-pet"
                      type="text"
                      value={petName}
                      onChange={(e) => setPetName(e.target.value)}
                      placeholder="Ex.: Pipoca (Shih Tzu)"
                      className="w-full px-4 py-3 rounded-xl bg-canvas/80 border border-ink/25 text-ink placeholder:text-ink-muted/60 text-sm font-medium focus:outline-none focus:border-ink transition-colors"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="contact-subject"
                    className="block text-sm font-bold text-ink"
                  >
                    Serviço ou interesse
                  </label>
                  <select
                    id="contact-subject"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-canvas/80 border border-ink/25 text-ink text-sm font-medium focus:outline-none focus:border-ink transition-colors"
                  >
                    {SERVICES.map((service) => (
                      <option key={service.id} value={service.title}>
                        {service.title}
                      </option>
                    ))}
                    <option value="Outro assunto">Outro assunto</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label
                    htmlFor="contact-message"
                    className="block text-sm font-bold text-ink"
                  >
                    Mensagem (opcional)
                  </label>
                  <textarea
                    id="contact-message"
                    rows={3}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Conte o porte do seu pet ou o que você precisa..."
                    className="w-full px-4 py-3 rounded-xl bg-canvas/80 border border-ink/25 text-ink placeholder:text-ink-muted/60 text-sm font-medium focus:outline-none focus:border-ink transition-colors resize-none"
                  />
                </div>

                {error && (
                  <p role="alert" className="text-sm font-bold text-red-900">
                    {error}
                  </p>
                )}

                <div className="pt-2 flex flex-col sm:flex-row sm:items-center gap-4">
                  <button
                    type="submit"
                    className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 rounded-full bg-ink text-canvas font-bold text-sm whitespace-nowrap shrink-0 transition-colors duration-150 hover:bg-ink-soft focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
                  >
                    <MessageCircle className="w-4 h-4" aria-hidden="true" />
                    <span>Enviar pelo WhatsApp</span>
                  </button>

                  {submittedUrl && (
                    <div className="flex items-center gap-2 text-sm font-semibold text-ink">
                      <CheckCircle2
                        className="w-4 h-4 text-ink shrink-0"
                        aria-hidden="true"
                      />
                      <span>
                        Mensagem pronta!{' '}
                        <a
                          href={submittedUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-bold underline decoration-ink underline-offset-2"
                        >
                          Abrir WhatsApp
                        </a>
                      </span>
                    </div>
                  )}
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
