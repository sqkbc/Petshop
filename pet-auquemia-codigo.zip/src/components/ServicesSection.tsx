import { motion } from 'motion/react';
import { ArrowUpRight, Droplets, HeartHandshake, Scissors, Sparkles, Car } from 'lucide-react';
import { SERVICES } from '../data/petShopData';
import { PetImage } from './PetImage';

interface ServicesSectionProps {
  onSelectService: (serviceTitle: string) => void;
}

function getServiceIcon(id: string) {
  switch (id) {
    case 'hidratacao-pelagem':
      return Sparkles;
    case 'unhas-ouvidos':
      return Scissors;
    case 'spa-patinhas':
      return HeartHandshake;
    case 'taxi-dog':
      return Car;
    default:
      return Droplets;
  }
}

export function ServicesSection({ onSelectService }: ServicesSectionProps) {
  const featuredBath = SERVICES[0];
  const featuredGrooming = SERVICES[1];
  const secondaryServices = SERVICES.slice(2);

  return (
    <section id="servicos" className="py-24 lg:py-32 bg-surface text-ink border-t border-hairline">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Editorial Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-12 items-end mb-14 lg:mb-16"
        >
          <div className="lg:col-span-7">
            <p className="text-sm font-bold text-ink mb-3">
              Serviços de cuidado
            </p>
            <h2 className="font-display font-semibold text-ink text-[clamp(2rem,3.8vw,3.25rem)] leading-[1.08] tracking-tight">
              Banho, tosa e cuidado completo.
            </h2>
          </div>
          <p className="lg:col-span-5 text-base font-medium text-ink-muted leading-relaxed">
            Toque em qualquer serviço para solicitar horário com a equipe pelo formulário ou WhatsApp.
          </p>
        </motion.div>

        {/* Asymmetric Bento Grid — Yellow Cards & Black Text */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* 01. Large Visual Feature Card */}
          <motion.button
            type="button"
            onClick={() => onSelectService(featuredBath.title)}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 lg:row-span-2 group text-left rounded-[2rem] overflow-hidden bg-elevated border border-ink/15 hover:border-ink flex flex-col justify-between transition-all duration-200 hover:-translate-y-1 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
          >
            <div className="relative aspect-[4/3] w-full overflow-hidden bg-canvas">
              {featuredBath.image && (
                <PetImage
                  src={featuredBath.image}
                  alt={featuredBath.imageAlt ?? featuredBath.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                />
              )}
            </div>

            <div className="p-7 sm:p-9 flex flex-col gap-3">
              <div className="flex items-center justify-between gap-4">
                <span className="text-xs font-bold text-ink tabular-nums">
                  {featuredBath.index} · {featuredBath.category}
                </span>
                <span className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-ink text-canvas transition-transform group-hover:scale-105">
                  <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                </span>
              </div>
              <h3 className="font-display font-semibold text-2xl sm:text-3xl text-ink">
                {featuredBath.title}
              </h3>
              <p className="text-[15px] font-medium text-ink-muted leading-relaxed max-w-md">
                {featuredBath.summary}
              </p>
            </div>
          </motion.button>

          {/* 02. Second Feature Card */}
          <motion.button
            type="button"
            onClick={() => onSelectService(featuredGrooming.title)}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, delay: 0.06, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-6 group text-left rounded-[2rem] overflow-hidden bg-elevated border border-ink/15 hover:border-ink text-ink grid grid-cols-1 sm:grid-cols-12 items-stretch transition-all duration-200 hover:-translate-y-1 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
          >
            <div className="sm:col-span-7 p-7 sm:p-8 flex flex-col justify-between gap-4">
              <div className="flex items-center justify-between gap-4">
                <span className="text-xs font-bold text-ink tabular-nums">
                  {featuredGrooming.index} · {featuredGrooming.category}
                </span>
                <span className="inline-flex items-center justify-center w-8 h-8 rounded-full bg-ink text-canvas transition-transform group-hover:scale-105">
                  <ArrowUpRight className="w-4 h-4" aria-hidden="true" />
                </span>
              </div>
              <div className="space-y-2">
                <h3 className="font-display font-semibold text-2xl text-ink">
                  {featuredGrooming.title}
                </h3>
                <p className="text-sm font-medium text-ink-muted leading-relaxed">
                  {featuredGrooming.summary}
                </p>
              </div>
            </div>

            <div className="sm:col-span-5 aspect-[4/3] sm:aspect-auto min-h-[190px] overflow-hidden">
              {featuredGrooming.image && (
                <PetImage
                  src={featuredGrooming.image}
                  alt={featuredGrooming.imageAlt ?? featuredGrooming.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
                />
              )}
            </div>
          </motion.button>

          {/* 03 - 06. Clean 2x2 Secondary Care Bento */}
          <div className="lg:col-span-6 grid grid-cols-1 sm:grid-cols-2 gap-6">
            {secondaryServices.map((service, idx) => {
              const Icon = getServiceIcon(service.id);
              return (
                <motion.button
                  key={service.id}
                  type="button"
                  onClick={() => onSelectService(service.title)}
                  initial={{ opacity: 0, y: 18 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-50px' }}
                  transition={{
                    duration: 0.55,
                    delay: 0.05 * idx,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className="group text-left rounded-[1.75rem] p-6 bg-elevated border border-ink/15 flex flex-col justify-between gap-5 transition-all duration-200 hover:-translate-y-1 hover:border-ink focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
                >
                  <div className="flex items-center justify-between gap-3">
                    <span className="inline-flex items-center justify-center w-10 h-10 rounded-2xl bg-ink text-canvas">
                      <Icon className="w-5 h-5" strokeWidth={2} aria-hidden="true" />
                    </span>
                    <span className="text-xs font-bold text-ink tabular-nums">
                      {service.index} · {service.category}
                    </span>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display font-semibold text-lg text-ink">
                        {service.title}
                      </h3>
                      <ArrowUpRight
                        className="w-4 h-4 text-ink shrink-0 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
                        aria-hidden="true"
                      />
                    </div>
                    <p className="text-sm font-medium text-ink-muted leading-relaxed">
                      {service.summary}
                    </p>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
