import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight, Expand, X } from 'lucide-react';
import { GALLERY_PHOTOS } from '../data/petShopData';
import { PetImage } from './PetImage';

const CARE_PILLARS = [
  {
    title: 'Atendimento sem pressa',
    description: 'Respeitamos o tempo e o temperamento de cada cão ou gato em sala tranquila.',
  },
  {
    title: 'Fórmulas suaves',
    description: 'Cosméticos botânicos seguros para pele sensível e pelagem saudável.',
  },
  {
    title: 'Contato direto em Uruçuí',
    description: 'Você acompanha tudo e combina busca ou horário direto pelo WhatsApp.',
  },
];

export function GallerySection() {
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  useEffect(() => {
    if (lightboxIndex === null) return;

    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setLightboxIndex(null);
      } else if (event.key === 'ArrowRight') {
        setLightboxIndex((prev) =>
          prev === null ? null : (prev + 1) % GALLERY_PHOTOS.length
        );
      } else if (event.key === 'ArrowLeft') {
        setLightboxIndex((prev) =>
          prev === null
            ? null
            : (prev - 1 + GALLERY_PHOTOS.length) % GALLERY_PHOTOS.length
        );
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxIndex]);

  const activePhoto =
    lightboxIndex !== null ? GALLERY_PHOTOS[lightboxIndex] : null;

  return (
    <section id="galeria" className="py-24 lg:py-32 bg-canvas text-ink border-t border-hairline">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-10">
        {/* Editorial Heading */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-80px' }}
          transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14"
        >
          <div className="space-y-3 max-w-xl">
            <p className="text-sm font-bold text-ink">
              Galeria & ambiente
            </p>
            <h2 className="font-display font-semibold text-ink text-[clamp(2rem,3.8vw,3.25rem)] leading-[1.08] tracking-tight">
              Momentos reais de carinho.
            </h2>
          </div>
          <p className="text-base font-medium text-ink-muted max-w-sm leading-relaxed">
            Clique em qualquer foto para ampliar e conhecer o cuidado da Pet Auquemia de perto.
          </p>
        </motion.div>

        {/* Asymmetric Editorial Photo Mosaic */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Large Focal Image */}
          <motion.button
            type="button"
            onClick={() => setLightboxIndex(0)}
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-60px' }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 group relative rounded-[2rem] overflow-hidden bg-elevated border border-ink/20 hover:border-ink aspect-[4/3] lg:aspect-auto lg:min-h-[460px] text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
          >
            <PetImage
              src={GALLERY_PHOTOS[0].src}
              alt={GALLERY_PHOTOS[0].alt}
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8 flex items-end justify-between gap-4">
              <p className="font-display font-medium text-lg sm:text-xl text-white max-w-md">
                {GALLERY_PHOTOS[0].caption}
              </p>
              <span className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-canvas text-ink shrink-0 transition-transform group-hover:scale-105">
                <Expand className="w-4 h-4" aria-hidden="true" />
              </span>
            </div>
          </motion.button>

          {/* Stacked Right Pair */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-6">
            {GALLERY_PHOTOS.slice(1).map((photo, offsetIdx) => {
              const photoIdx = offsetIdx + 1;
              return (
                <motion.button
                  key={photo.id}
                  type="button"
                  onClick={() => setLightboxIndex(photoIdx)}
                  initial={{ opacity: 0, y: 18 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: '-60px' }}
                  transition={{
                    duration: 0.6,
                    delay: 0.08 * photoIdx,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className="group relative rounded-[2rem] overflow-hidden bg-elevated border border-ink/20 hover:border-ink aspect-[4/3] lg:aspect-[16/10] text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ink"
                >
                  <PetImage
                    src={photo.src}
                    alt={photo.alt}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-5 sm:p-6 flex items-end justify-between gap-4">
                    <p className="font-display font-medium text-base sm:text-lg text-white">
                      {photo.caption}
                    </p>
                    <span className="inline-flex items-center justify-center w-9 h-9 rounded-full bg-canvas text-ink shrink-0 transition-transform group-hover:scale-105">
                      <Expand className="w-4 h-4" aria-hidden="true" />
                    </span>
                  </div>
                </motion.button>
              );
            })}
          </div>
        </div>

        {/* Quiet 3-Column Care Manifesto Strip */}
        <div className="mt-16 pt-12 border-t border-hairline grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
          {CARE_PILLARS.map((pillar) => (
            <div key={pillar.title} className="space-y-2">
              <h3 className="font-display font-semibold text-xl text-ink">
                {pillar.title}
              </h3>
              <p className="text-[15px] font-medium text-ink-muted leading-relaxed">
                {pillar.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Accessible Lightbox Modal */}
      {activePhoto && lightboxIndex !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={activePhoto.alt}
          onClick={() => setLightboxIndex(null)}
          className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8"
        >
          <div
            onClick={(event) => event.stopPropagation()}
            className="relative max-w-4xl w-full rounded-[2rem] overflow-hidden bg-canvas border-2 border-ink shadow-2xl"
          >
            <button
              type="button"
              onClick={() => setLightboxIndex(null)}
              aria-label="Fechar foto ampliada"
              className="absolute top-4 right-4 z-10 w-10 h-10 rounded-full bg-ink text-canvas hover:bg-ink-soft inline-flex items-center justify-center transition-colors focus-visible:outline-2 focus-visible:outline-canvas"
            >
              <X className="w-5 h-5" aria-hidden="true" />
            </button>

            <div className="aspect-[4/3] w-full bg-ink">
              <PetImage
                src={activePhoto.src}
                alt={activePhoto.alt}
                loading="eager"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-5 sm:p-6 flex items-center justify-between gap-4 bg-canvas text-ink border-t border-hairline">
              <p className="font-display font-semibold text-base sm:text-lg">
                {activePhoto.caption}
              </p>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() =>
                    setLightboxIndex(
                      (lightboxIndex - 1 + GALLERY_PHOTOS.length) %
                        GALLERY_PHOTOS.length
                    )
                  }
                  aria-label="Foto anterior"
                  className="w-10 h-10 rounded-full border border-ink/30 text-ink hover:bg-ink hover:text-canvas inline-flex items-center justify-center transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setLightboxIndex((lightboxIndex + 1) % GALLERY_PHOTOS.length)
                  }
                  aria-label="Próxima foto"
                  className="w-10 h-10 rounded-full border border-ink/30 text-ink hover:bg-ink hover:text-canvas inline-flex items-center justify-center transition-colors"
                >
                  <ChevronRight className="w-5 h-5" aria-hidden="true" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
